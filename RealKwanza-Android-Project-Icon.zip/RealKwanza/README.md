# Real Kwanza (Android)

Aplicação Android simples para converter Real brasileiro (BRL) em Kwanza angolano (AOA).

## Dados de câmbio
- Fonte: ExchangeRate-API Open Access: https://open.er-api.com/v6/latest/USD
- Documentação e condições: https://www.exchangerate-api.com/docs/free
- O app calcula BRL→AOA usando AOA por USD dividido por BRL por USD, ambas da mesma resposta e data.
- A fonte atualiza aproximadamente diariamente. A app mostra o timestamp informado pela fonte e não inventa taxa se a consulta falhar.
- A cotação é indicativa; não é a taxa garantida de um banco/casa de câmbio e não inclui comissões.

## Como gerar o APK
1. Instale o Android Studio num computador.
2. Abra a pasta `RealKwanza` no Android Studio e aceite a instalação dos componentes sugeridos.
3. Use **Build > Build APK(s)**.
4. O APK de debug será gerado normalmente em `app/build/outputs/apk/debug/app-debug.apk`.

Requisitos de build: Android SDK 35 e Gradle compatível com Android Gradle Plugin 8.7.3. O app precisa de internet para buscar a cotação.


## Conversão nos dois sentidos
A interface permite alternar entre BRL → AOA e AOA → BRL pelo botão “Inverter moedas”. As duas taxas são calculadas a partir da mesma publicação de taxas USD da ExchangeRate-API Open Access. A fonte atualiza aproximadamente uma vez por dia e exige atribuição: https://www.exchangerate-api.com/docs/free.
