# Real Kwanza — versão com ícone

Este pacote inclui o ícone Real Kwanza nos recursos Android `mipmap-*` e referencia-o no `AndroidManifest.xml`.

Para compilar na nuvem, envie este ZIP para o repositório e use um workflow que extraia `RealKwanza-Android-Project-Bidirectional-Icon.zip` para a pasta de trabalho. O projeto está em `RealKwanza/` dentro do ZIP.
